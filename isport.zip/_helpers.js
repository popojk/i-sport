function getUser (req) {
  return req.user
}

module.exports = {
  getUser
}
